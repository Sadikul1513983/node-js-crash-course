for(let i=0 ; i< 5 ;i++){
    console.log('in loop:',i)
}

const namee=['shaun','pullock','bond']
for(let i =0 ; i < namee.length ; i++){
    let html=`<div>${namee[i]}</div>`
    console.log(html)
}



let i=5
while(i<5){
    console.log('val of is :',i)
    i++
}



const age=20
if(age>20){
    console.log('you are over ')
}

const ninjass=['shaun','haasa']
if(ninjass.length>3){
    console.log('yeah bingo')
}


const passWord='passs@ss'
if(passWord.length >=8){
    console.log('yes')
}else{
    console.log('no')
}
if(passWord.length >=8 && passWord.includes('@')){
    console.log('yes')
}else{
    console.log('no')
}
if(passWord.length >=12 && passWord.includes('@')){
    console.log('yes')
}else{
    console.log('no')
}
if(passWord.length >=16 && passWord.includes('@')){
    console.log('yes')
}else{
    console.log('no')
}


let user=false
if(!user){
    console.log(user)
}


const score=[50,55,60,65,70]
for(let i=0 ;  i< score.length;i++){
    if(score[2]==60){
        console.log('we found it')
    }else{
        console.log('no yherer is no body of that anme')
    }
}



switch (new Date().getDay()) {
    case 0:
      day = "Sunday";
      break;
    case 1:
      day = "Monday";
      break;
    case 2:
       day = "Tuesday";
      break;
    case 3:
      day = "Wednesday";
      break;
    case 4:
      day = "Thursday";
      break;
    case 5:
      day = "Friday";
      break;
    case 6:
      day = "Saturday";
  }



let agee=30;
if(true){
    age=40;
    console.log('inside 1st code block',age)
}
console.log('outside 1st code block',age)