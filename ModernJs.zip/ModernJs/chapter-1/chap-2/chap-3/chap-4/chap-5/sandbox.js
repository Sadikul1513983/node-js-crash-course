const pera=document.querySelector('.error')
const paras1=document.querySelectorAll('p')
const paras2=document.querySelector('p')
console.log(paras2.innerHTML)