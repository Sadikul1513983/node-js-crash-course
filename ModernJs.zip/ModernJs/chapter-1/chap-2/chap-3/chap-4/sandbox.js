let user={
    name:'mario',
    age:30,
    email:'bauj@gamil.com',
    location:'barlin',
    blogs:['why does it feels like nigth today','something in heres not right today'],
    login:function(){
        console.log('user')
    }

}
user.login()

let area=7.7
console.log(Math)
console.log(Math.floor(area))
console.log(Math.random(area))
console.log(Math.max(3,4))
console.log(Math.ceil(5.5))
console.log(Math.trunc(5.6))
console.log(Math.E)
console.log(Math.pow(2,3))
console.log(Math.cos(2))
console.log(Math)


const userOne={name:'ruy', age:30}
const userTwo=userOne
userOne.age=40
console.log(userOne,userTwo)