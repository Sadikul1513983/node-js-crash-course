const speak=function(){
    console.log('good day')
}

gret()
gret()
gret()

speak()
speak()
speak()

function gret(){
    console.log('hello')
}



const speak1=function(name='langha' ,time='night'){
    console.log(`good ${name} and late ${time}`)
}

speak1()

const calcArea=function(r){
    return 3.14*r
}
const r=calcArea(4)
console.log(r)




const hel=function(){
    console.log('hello')
}
hel()


const hell=()=>{
    console.log('hell')
}
hell()



const bill=function(pro,tx){
    let total=0
    for (let index = 0; index < pro.length; index++) {
        total +=pro[index]+pro[index]*tx
    }
    return total
}

const myFun=(cb)=>{
    let val=50
    cb(val)
}
myFun((val)=>{
    console.log(val)
})