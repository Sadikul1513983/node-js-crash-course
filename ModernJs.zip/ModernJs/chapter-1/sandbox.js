alert('hello world')
let myAge=25;
let year=2020;
console.log(myAge,year)

const points=100;
console.log(points)
var score=100;
console.log(score)

let email='mario@gmail.com'
console.log(email)

let firstName='bardon'
let lastName='sardon'
let fulName=firstName+ '' +lastName
console.log(fulName)
console.log(fulName[0])

console.log(fulName.toUpperCase())
console.log(fulName.toLowerCase())

let index=email.indexOf('@')
console.log(index)

let result=email.slice(0,10)
let result1=email.substring(0,10)
let result2=email.replace('m','w')

let radius=10
const pi=Math.PI();
console.log(radius/pi)

let likes=10
likes=likes+1

let nan='to'
let man=1
console.log(nan/man)


const title='best of mario'
const author='mario'
const like=30

let result4=`title:${title} author:${author} and 
like:${like}`



let ninjas=['mario','deo']
console.log(ninjas[0])
console.log(ninjas.length)
let res=ninjas.push('ken')


let age=8
console.log(age,age+3,`the age is${age}`)
console.log(true,false)
let email2='luajasj@gamil.com'
let res1=email2.includes('@')

console.log(age==25)
console.log(age==30)
console.log(age!=25)
console.log(age>=25)
console.log(age<=25)
console.log(age<='25')
console.log(age==25)


let result5=Number('hello')
console.log(result5)





