const { fstat } = require('fs');
const http=require('http')
const_ = require('lodash')
const server=http.createServer((res,req)=>{
    console.log(req.url , req.method);


    const num=_.random(0,20);
    console.log(num)



    const greet=_.once(()=>{
            console.log('hello')
    })
    greet()
    greet()
    greet()

    

     res.setHeader('content-type','text/html');
    let path='./view';
    switch(req.url){
        case '/':
            path +='index.html'
            res.statusCode=200;
            break;
        case './about':
            path +='about.html'
            // res.statusCode=200;
            res.statusCode=301;
            res.setHeader('Location','./about')
            res.end()
            break;
            // 
            case './about-me':
            path +='about.html'
            // res.statusCode=200;
            res.statusCode=301;
            break;
            case './about-us':
            path +='about.html'
            // res.statusCode=200;
            res.statusCode=301;
            break;
        default:
            path +='404.html'
            res.statusCode=404;
            break;

    }

    // res.write('<p> hello,ninjas</p>')
    // res.write("<head><link rel='StyleSheet' href='#'></head>")
    // res.write('<p> hello agian,ninjas</p>')
    // res.end()

    // fs.readFile('./view/index.html',(err,data)=>{
    //     if(err){
    //         console.log(err)
    //         res.end()
    //     }else{
    //         //res.write(data)
    //         res.statusCode=200;
    //         res.end()
    //     }
    // })
});



server.listen(3000, 'localhost', ()=>{
    console.log('listening from on port 3000')
})