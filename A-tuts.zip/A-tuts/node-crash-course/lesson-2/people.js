const people=['yoshi','mario','doe']
const ages=[20,30,40]
console.log(people)
module.export={
    people,ages
}
