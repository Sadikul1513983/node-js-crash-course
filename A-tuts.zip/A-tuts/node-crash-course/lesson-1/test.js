const name0='mario'
console.log(name0)
const name1='yoshi'
console.log(name1)

const greet=()=>{
    console.log( ` hello ${name0}`)
}
greet('doe')